module.exports = {
  testMatch: ["**/tests/**/*.js"], // Inclut tous les fichiers dans le dossier tests
};
