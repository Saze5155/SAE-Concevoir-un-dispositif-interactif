<template>
  <div id="app">
    <h1>MovieMind</h1>
    <router-view />
  </div>
</template>

<script setup></script>

<style>
body {
  font-family: "Segoe UI", sans-serif;
  background: #f9f9f9;
  margin: 0;
  padding: 20px;
}
</style>
